Sprites & sound files from Persona 4 Arena.

Sprite animations and ini-edit made by The Professor and Pixelrushe AKA Bearsona 4 Bent Duo.