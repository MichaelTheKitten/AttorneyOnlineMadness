Sprites & sound files from Persona 4 Arena.

Sprite animations and ini-edit made by Pixelrushe and INCEY.